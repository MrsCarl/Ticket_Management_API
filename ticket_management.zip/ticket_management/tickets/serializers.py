from rest_framework import serializers
from .models import Ticket, DutyRoster


class TicketSerializer(serializers.ModelSerializer):
    assigned_employee = serializers.StringRelatedField()

    class Meta:
        model = Ticket
        fields = '__all__'


class DutyRosterSerializer(serializers.ModelSerializer):
    employee = serializers.StringRelatedField()

    class Meta:
        model = DutyRoster
        fields = '__all__'
