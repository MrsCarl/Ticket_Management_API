import json
from datetime import datetime, date
from rest_framework import viewsets
from .models import Ticket, Employee, DutyRoster
from .serializers import TicketSerializer, DutyRosterSerializer
from rest_framework.decorators import api_view
from rest_framework.response import Response
from django.shortcuts import render


@api_view(['GET'])
def list_tickets(request):
    tickets = Ticket.objects.all()
    serializer = TicketSerializer(tickets, many=True)
    return Response(serializer.data)


@api_view(['POST'])
def create_ticket(request):
    serializer = TicketSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        assign_ticket_to_employee(serializer.instance)
        return Response(serializer.data, status=201)
    return Response(serializer.errors, status=400)


def assign_ticket_to_employee(ticket):
    date = datetime.now().date()
    available_employees = Employee.objects.filter(dutyroster__date=date, dutyroster__is_available=True)

    # Count the total number of assigned tickets
    assigned_tickets_count = Ticket.objects.exclude(assigned_employee=None).count()

    # Calculate the index of the next available employee based on the assigned tickets count
    next_employee_index = assigned_tickets_count % available_employees.count()

    # Get the next available employee based on the calculated index
    assigned_employee = available_employees[next_employee_index]

    ticket.assigned_employee = assigned_employee
    ticket.save()


@api_view(['PUT'])
def update_ticket(request, ticket_id):
    try:
        ticket = Ticket.objects.get(id=ticket_id)
    except Ticket.DoesNotExist:
        return Response(status=404)

    serializer = TicketSerializer(ticket, data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data)
    return Response(serializer.errors, status=400)


@api_view(['DELETE'])
def delete_ticket(request, ticket_id):
    try:
        ticket = Ticket.objects.get(id=ticket_id)
    except Ticket.DoesNotExist:
        return Response(status=404)

    ticket.delete()
    return Response(status=204)


def ticket_allocation_dashboard(request):
    date = datetime.today()

    # Retrieve the tickets queryset
    # tickets = Ticket.objects.all()

    # Pass the tickets queryset to the template context
    # context = {'tickets': tickets}

    duty_roster = DutyRoster.objects.all # filter(date=date)
    context = {'duty_roster': duty_roster}
    return render(request, 'ticket_allocation.html', context)

def ticket_details(request):

    # Retrieve the tickets queryset
    tickets = Ticket.objects.all()

    # Pass the tickets queryset to the template context
    context = {'tickets': tickets}
    return render(request, 'Ticket_details.html', context)
