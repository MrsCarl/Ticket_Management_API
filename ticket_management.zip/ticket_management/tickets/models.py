from django.db import models
class Employee(models.Model):
    name = models.CharField(max_length=100)
    start_time = models.TimeField()
    end_time = models.TimeField()

    def __str__(self):
        return self.name

class DutyRoster(models.Model):
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE)
    date = models.DateField()
    is_available = models.BooleanField(default=True)

    def __str__(self):
        return self.name
class Ticket(models.Model):
    ticket_number = models.CharField(max_length=50)
    creation_date = models.DateField()
    description = models.TextField()
    resolution_end_date = models.DateField()
    assigned_employee = models.ForeignKey(Employee, on_delete=models.SET_NULL, null=True)

    def __str__(self):
        return self.ticket_number
