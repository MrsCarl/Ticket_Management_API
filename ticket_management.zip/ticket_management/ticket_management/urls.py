"""
URL configuration for ticket_management project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from tickets.views import list_tickets, create_ticket, update_ticket, delete_ticket, ticket_allocation_dashboard,ticket_details

urlpatterns = [
    path('tickets/', list_tickets, name='list_tickets'),
    path('tickets/create/', create_ticket, name='create_ticket'),
    path('tickets/update/<int:ticket_id>/', update_ticket, name='update_ticket'),
    path('tickets/delete/<int:ticket_id>/', delete_ticket, name='delete_ticket'),
    path('tickets/allocate/', ticket_allocation_dashboard, name='ticket_allocation_dashboard'),
    path('tickets/dashboard/', ticket_details , name='ticket_dashboard'),
]